# GrantMatch — Archéologie & SHS

Outil interactif de recherche de financements postdoctoraux pour les chercheurs en archéologie et sciences humaines.

## Structure du projet

```
grantmatch-site/
├── index.html      ← Interface (ne pas modifier sauf pour le design)
├── grants.json     ← Données des bourses (à mettre à jour chaque année)
└── README.md
```

## Mise en ligne sur GitHub Pages (5 minutes)

1. Connectez-vous sur [github.com](https://github.com)
2. Cliquez sur **"New repository"** (bouton vert en haut à droite)
3. Nommez-le `grantmatch` (ou ce que vous voulez)
4. Cochez **"Public"**, puis **"Create repository"**
5. Cliquez sur **"uploading an existing file"**
6. Glissez-déposez les 3 fichiers (`index.html`, `grants.json`, `README.md`)
7. Cliquez **"Commit changes"**
8. Allez dans **Settings → Pages → Source → "Deploy from a branch" → main → / (root)**
9. Cliquez **Save**

Votre site sera accessible à :  
`https://VOTRE-NOM-GITHUB.github.io/grantmatch/`

(La mise en ligne prend 1-2 minutes après le premier commit.)

---

## Mettre à jour les données (chaque année)

**Seul `grants.json` doit être modifié.** Vous n'avez jamais besoin de toucher à `index.html`.

### Modifier une deadline

Trouvez le bloc correspondant dans `grants.json` et changez le champ `"deadline"` :

```json
{
  "id": "msca",
  "deadline": "2027-09-10",   ← changer cette date
  ...
}
```

### Ajouter une nouvelle bourse

Copiez un bloc existant et modifiez les champs. Les champs `elig_rules` disponibles sont :

| Règle | Description |
|---|---|
| `"phd": ["yes"]` | Doctorat requis |
| `"age": ["lt1","1to2",...]` | Ancienneté de thèse acceptée |
| `"stat": ["funded","mcf"]` | Statut institutionnel requis |
| `"mono_required": true` | Thèse publiée en monographie requise |
| `"zones_any": ["asie_se",...]` | Au moins une de ces zones doit être sélectionnée |
| `"links_required": ["l_jp"]` | Lien institutionnel requis |
| `"exclude_if_had": ["h_msca"]` | Masqué si déjà perçu |

### Codes des zones géographiques

`france` · `europe_occ` · `europe_orient` · `med` · `afrique_nord` · `afrique_ss` · `asie_sud` · `asie_se` · `asie_e` · `asie_c` · `ameriques` · `oceanie`

### Codes des spécialités

`prehist` · `protohistoire` · `antiquite` · `bioarch` · `archeo_mort` · `paleogenom` · `medieval` · `anthropo` · `archeo_env` · `archeo_sci` · `numismat` · `histoire_art` · `autre_shs`

### Mettre à jour la date de dernière mise à jour

Au début de `grants.json` :

```json
"meta": {
  "last_updated": "2027-01-15",   ← changer cette date
  "version": "3.0"
}
```

---

## Calendrier .ics

Le bouton "Exporter le calendrier" génère un fichier `.ics` avec :
- Toutes les dates de clôture des bourses correspondant au profil
- Un rappel automatique **6 semaines avant** chaque deadline
- Compatible Apple Calendar, Google Calendar, Outlook

Pour Google Calendar : importer via *Paramètres → Importer et exporter → Importer le fichier .ics*
